import React from "react";
import "./Header.css";

function Header() {
  return (
    <header className="header">
      <button className="logo" onClick={() => window.location.href = "/"}>
        Mi-Tiendita
      </button>
      <input type="text" placeholder="Buscar un producto..." className="search" />
      <div className="actions">
        <button className="cart">Carrito S/ 0.00</button>
        <button className="account">Usuario cuenta</button>
      </div>
    </header>
  );
}

export default Header;