import './Aside.css'

const Aside = () =>{
    const handleProductosClick = () => {
        window.location.href = "/productos";
    };

    return(
        <div className='Aside'>
            <ul>
                <li><button className="aside-btn">CATEGORIAS</button></li>
                <li>
                    <button className="aside-btn" onClick={handleProductosClick}>
                        PRODUCTOS
                    </button>
                </li>
                <li><button className="aside-btn">NOSOTROS</button></li>
                <li className='Ofertas'>
                    <button className="aside-btn ofertas-btn">
                        OFERTAS {String.fromCharCode(0x270B)}
                    </button>
                </li>
            </ul>
        </div>
    )
}
export default Aside;