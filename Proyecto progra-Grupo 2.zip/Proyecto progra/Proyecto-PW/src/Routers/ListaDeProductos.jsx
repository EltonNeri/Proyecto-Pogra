import Producto from '../Components//TablaProducto/TablaProdu.jsx';
import Paginacion from '../Components/Paginacion/Paginacion.jsx';
const Productos = () => {
    return (
        <>
        <Producto />
        <Paginacion/>
        </>
    );
}
export default Productos;