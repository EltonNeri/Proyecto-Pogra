
import React from 'react';
import Editar from '../Components/EditarProdu/Editar.jsx';
const EditarProdu = () => {
    return (
        <Editar />
    )

}
export default EditarProdu;