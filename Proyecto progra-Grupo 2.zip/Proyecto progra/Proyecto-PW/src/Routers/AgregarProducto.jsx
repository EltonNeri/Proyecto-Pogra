import AgregarProdu from "../Components/AgregarProducto/AgregarProdu.jsx"
const AgregarProducto = () => {
    return(
        <AgregarProdu />
    )
}
export default AgregarProducto;