import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';
import { createBrowserRouter,RouterProvider } from 'react-router';
import Header from './Components/Header/Header.jsx';
import Aside from './Components/Aside/Aside.jsx';
import Productos from './Routers/ListaDeProductos.jsx'; 
import AgregarProducto from './Components/AgregarProducto/AgregarProdu.jsx';
import Editar from './Components/EditarProdu/Editar.jsx';


const router =createBrowserRouter ([
  {
    path: "/",
    element: <App/>
  },
  {
    path: "/productos",
    element: <Productos/>
  },
  {
    path: "/agregar-producto",
    element: <AgregarProducto />
  },
  {
    path: "/editar-producto",
    element: <Editar />
  }

])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Header/>
    <Aside />
    <RouterProvider router={router}/>
  </React.StrictMode>
);