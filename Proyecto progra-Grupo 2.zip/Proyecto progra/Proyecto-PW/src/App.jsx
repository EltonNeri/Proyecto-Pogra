import { useState } from 'react'

import './App.css'
import Cards from './Components/Cards/Cards.jsx'
import TablaUser from './Components/TablaUsuarios/TablaUser.jsx'
import DetalleUser from './Components/DetalleUsuario/DetalleUser.jsx'
import ListaProdu from './Components/ListaProductos/ListaProdu.jsx'
import Paginacion from './Components/Paginacion/Paginacion.jsx'

function App() {
   const [selectedUser, setSelectedUser] = useState(null);
  return (
      <div>
      <main className='dashboard'>
        <section className='resumen'>
          <Cards  />

        </section>
        <section className='seccion-usuario'>
          <TablaUser onSelectUser={setSelectedUser} />
          {selectedUser && <DetalleUser user={selectedUser} />}
        </section>
        <section className='seccion-ordenes'>
          <ListaProdu/> 
          
          <Paginacion/>
        </section>
      </main>
    </div>

  )
}

export default App
